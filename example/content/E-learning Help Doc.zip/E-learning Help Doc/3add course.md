<b>3.Add Course</b><br>You can add and manage courses using this section.<br><b>To create the course follow the following steps-</b><br>
1.Click on the Manage Course Menu<br>
2.Then click on the Add New Course button<br>3.Fill the required fields<br>
4.In the Upload Logo section you can select the image which will be displayed on the Course section on the dashboard and the course-subject Page in the mobilw application.<br>5.To do this, click browse button After that you can upload a new image from your computer.<br>6.After filling all the required fields click on the Submit button.![add course]( https://drive.google.com/uc?export=view&id=1HeUXwR6UwOgzWghKBnxp2uTur2Iz-e_W)
