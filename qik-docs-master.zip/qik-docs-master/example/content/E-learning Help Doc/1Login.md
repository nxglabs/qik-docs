<b>1.Login</b><br>
Before being allowed to use the site administration tools, Admin will be asked to login.The login screen for the Admin asks for a username and password.<br><b>To login to the E-Learning Application Admin Portal</b><br>
1.Enter your Username and Password<br>
2.Click the Login button to get access to the Admin Portal.<br> 
If you forget your password, you click the ’forget password?’ link. Follow the on-screen instructions to get an email with a link to reset your password.
Once you have successfully logged in, you will be greeted by the Dashboard in the Admin Portal.![Login](https://drive.google.com/uc?export=view&id=1m5arrcfDK_HrjoidsxAr2VBaTLaF70yM)

