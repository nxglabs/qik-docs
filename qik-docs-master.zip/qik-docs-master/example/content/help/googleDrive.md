/*
Title: googleDrive
*/

1. onen google drive and Right click the image you want to share and click Share...

2. Click Advanced and change the Who can access option to anyone with the link or Nxglabs(in same oraganization)

3. Copy the link to share and you will have something like this :
https://drive.google.com/file/d/FILE_ID/view?usp=sharing

4. Copy the FILE_ID to make a link like this:
https://drive.google.com/uc?export=view&id=FILE_ID

5. Insert image in Markdown as ususal using the link from above step.
For example: 
![markdownImageEx](https://drive.google.com/uc?export=view&id=1fiYOcu_Z39b1FX_BMbu-KquXDgTJzOWl)
