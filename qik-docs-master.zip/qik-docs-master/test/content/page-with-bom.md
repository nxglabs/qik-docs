﻿/*
Title: Example Page With BOM
Sort: 3
*/

This is some example content if a file that has a [BOM](https://en.wikipedia.org/wiki/Byte_order_mark) character.